

--- PORTUGUÊS

Delimitador de campo: ponto-vírgula (;)

Separador decimal: ponto (.)


______________________________________


--- ENGLISH

Field delimiter: semicolon (;)

Decimal separator: point (.)


______________________________________


--- ESPAÑOL

Delimitador de campo: punto y coma (;)

Separador decimal: punto (.)


______________________________________